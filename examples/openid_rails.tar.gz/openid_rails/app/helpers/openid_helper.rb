module OpenidHelper
end
